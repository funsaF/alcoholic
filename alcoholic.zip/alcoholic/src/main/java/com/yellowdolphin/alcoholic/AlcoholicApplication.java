package com.yellowdolphin.alcoholic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlcoholicApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlcoholicApplication.class, args);
	}

}
