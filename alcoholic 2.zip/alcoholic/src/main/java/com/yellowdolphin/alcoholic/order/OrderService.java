package com.yellowdolphin.alcoholic.order;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class OrderService {
	public List<Order> getOrder(){
	return List.of(
			new Order(
					"od202412230606"
					,1
					,580
					,"funsa"
					,"63522"
					,"0"
					,LocalDate.of(2024, Month.DECEMBER, 23)
					)
			);	
	}
}
