package com.yellowdolphin.alcoholic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlcoholicApplicationTests {

	@Test
	void contextLoads() {
	}

}
