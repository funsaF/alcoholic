package com.yellowdolphin.alcoholic.order;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
	// select * from cuod where buyer_ext = ?
//	@Query("SELECT o FROM Order o WHERE o.buyer_ext = ?1") //不能用會壞掉
	Optional<Order> findCuodByBuyerExt(String buyerExt);
}
