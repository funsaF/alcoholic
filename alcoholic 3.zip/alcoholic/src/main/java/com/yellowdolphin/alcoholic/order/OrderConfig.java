package com.yellowdolphin.alcoholic.order;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OrderConfig {
	@Bean
	CommandLineRunner commandLineRunner(OrderRepository repository) {
		return args -> {
			Order test1 = new Order("od202412230606", 1, 580, "funsa", "63522", "0",
					LocalDate.now());
			Order test2 = new Order("od202412333333", 1, 580, "funsa", "63522", "0",
					LocalDate.now());
			repository.saveAll(List.of(test1, test2));
		};
	}
}
