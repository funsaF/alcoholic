package com.yellowdolphin.alcoholic.order;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="cuod")
public class Order {
	@Id
	@SequenceGenerator(name = "order_no", sequenceName = "order_no", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_no")
	private Long orderNo;
	private String itemNo;
	private Integer qty;
	private Integer fixPrice;
	private String buyer;
	private String buyerExt;
	private String payInd;
	private LocalDate proceDatetime;

	public Order() {
	}

	public Order(Long orderNo, String itemNo, Integer qty, Integer fixPrice, String buyer, String buyerExt,
			String payInd, LocalDate proceDatetime) {
		this.orderNo = orderNo;
		this.itemNo = itemNo;
		this.qty = qty;
		this.fixPrice = fixPrice;
		this.buyer = buyer;
		this.buyerExt = buyerExt;
		this.payInd = payInd;
		this.proceDatetime = proceDatetime;
	}

	public Order(String itemNo, Integer qty, Integer fixPrice, String buyer, String buyerExt, String payInd,
			LocalDate proceDatetime) {
		super();
		this.itemNo = itemNo;
		this.qty = qty;
		this.fixPrice = fixPrice;
		this.buyer = buyer;
		this.buyerExt = buyerExt;
		this.payInd = payInd;
		this.proceDatetime = proceDatetime;
	}

	public Long getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Long orderNo) {
		this.orderNo = orderNo;
	}

	public String getItemNo() {
		return itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public Integer getFixPrice() {
		return fixPrice;
	}

	public void setFixPrice(Integer fixPrice) {
		this.fixPrice = fixPrice;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public String getBuyerExt() {
		return buyerExt;
	}

	public void setBuyerExt(String buyerExt) {
		this.buyerExt = buyerExt;
	}

	public String getPayInd() {
		return payInd;
	}

	public void setPayInd(String payInd) {
		this.payInd = payInd;
	}

	public LocalDate getProceDatetime() {
		return proceDatetime;
//		return LocalDate.now();
	}

	public void setProceDatetime(LocalDate proceDatetime) {
		this.proceDatetime = proceDatetime;
	}

	@Override
	public String toString() {
		return "order [orderNo=" + orderNo + ", itemNo=" + itemNo + ", qty=" + qty + ", fixPrice=" + fixPrice
				+ ", buyer=" + buyer + ", buyerExt=" + buyerExt + ", payInd=" + payInd + ", proceDatetime="
				+ proceDatetime + "]";
	}

}
