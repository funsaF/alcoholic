# Untitled Diagram documentation
## Summary

- [Introduction](#introduction)
- [Database Type](#database-type)
- [Table Structure](#table-structure)
	- [item](#item)
	- [order](#order)
- [Relationships](#relationships)
- [Database Diagram](#database-Diagram)

## Introduction

## Database type

- **Database system:** PostgreSQL
## Table structure

### item

| Name        | Type          | Settings                      | References                    | Note                           |
|-------------|---------------|-------------------------------|-------------------------------|--------------------------------|
| **item_no** | VARCHAR(255) | 🔑 PK, not null , unique |  | |
| **item_name** | TEXT | not null  |  | |
| **main_pic** | VARCHAR(255) | not null  |  | |
| **subseq** | VARCHAR(255) | not null  |  | |
| **subname** | TEXT | not null  |  | |
| **subpic** | VARCHAR(255) | not null  |  | |
| **price** | SMALLINT | not null  |  | |
| **sale_ind** | SMALLINT | not null  |  | |
| **sale_desc** | TEXT | not null  |  | | 


### order

| Name        | Type          | Settings                      | References                    | Note                           |
|-------------|---------------|-------------------------------|-------------------------------|--------------------------------|
| **order_no** | VARCHAR(255) | 🔑 PK, not null , unique |  | |
| **item_no** | VARCHAR(255) | not null  |  | |
| **qty** | SMALLINT | not null  |  | |
| **fix_price** | SMALLINT | not null  |  | |
| **buyer** | VARCHAR(255) | not null  |  | |
| **buyer_ext** | TEXT | not null  |  | |
| **pay_ind** | CHAR(1) | not null  |  | |
| **proce_datetime** | TIMESTAMP | not null  |  | | 


## Relationships


## Database Diagram

```mermaid
erDiagram
	item {
		VARCHAR(255) item_no
		TEXT item_name
		VARCHAR(255) main_pic
		VARCHAR(255) subseq
		TEXT subname
		VARCHAR(255) subpic
		SMALLINT price
		SMALLINT sale_ind
		TEXT sale_desc
	}

	order {
		VARCHAR(255) order_no
		VARCHAR(255) item_no
		SMALLINT qty
		SMALLINT fix_price
		VARCHAR(255) buyer
		TEXT buyer_ext
		CHAR(1) pay_ind
		TIMESTAMP proce_datetime
	}
```